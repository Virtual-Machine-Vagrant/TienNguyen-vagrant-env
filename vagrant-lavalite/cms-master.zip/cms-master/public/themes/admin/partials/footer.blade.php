      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          {!!trans('cms.version')!!}
        </div>
        <strong>{!!trans('cms.all.rights')!!}
      </footer>